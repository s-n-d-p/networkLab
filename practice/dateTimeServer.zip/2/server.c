#include<stdio.h>
#include<sys/types.h>
#include <sys/socket.h>
#include<netdb.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<math.h>
#include<signal.h>

#define BUFFER_SIZE 1024
#define BACKLOG 5

char buffer[BUFFER_SIZE];

void sig_handler(int signo){
	if(signo == SIGINT){
		printf("\nServer : Exiting"), exit(0);
	}
}

int main(int argc,char *argv[]){

	if(argc != 4){
		printf("Usage: ./server <server_port_number> <timeServer_ip> <timeServer_port_number>\n");
		exit(1);
	}

	signal(SIGINT,sig_handler);

	pid_t pid;
	int sockfd,status,newfd;
	struct addrinfo hints, *res,*p;
	struct sockaddr_storage peer_addr;
	socklen_t peer_addr_size;
	memset(&hints,0,sizeof hints);
	hints.ai_flags = AI_PASSIVE;
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;

	status = getaddrinfo(NULL,argv[1],&hints,&res);
	if(status != 0){
		fprintf(stderr, "Server, getaddrinfo: %s\n",gai_strerror(status));
		exit(EXIT_FAILURE);
	}
	for(p = res; p != NULL; p = p->ai_next){
		sockfd = socket(p->ai_family,p->ai_socktype,p->ai_protocol);
		if(sockfd == -1) continue;
		if(bind(sockfd,p->ai_addr,p->ai_addrlen) == 0) break;
		close(sockfd);
	}
	freeaddrinfo(res);
	if(p == NULL){
		fprintf(stderr, "Could not bind\n");
		exit(EXIT_FAILURE);
	}

	//socket is binded
	//lets connect to timeServer now


	int sockfd1,status1,newfd1;
	struct addrinfo hints1, *res1,*p1 ;
	memset(&hints1,0,sizeof hints1);
	hints1.ai_family = AF_UNSPEC;
	hints1.ai_socktype = SOCK_STREAM;

	status1 = getaddrinfo(argv[2],argv[3],&hints1,&res1);
	if(status1 != 0){
		fprintf(stderr, "Client, getaddrinfo: %s\n",gai_strerror(status1));
		exit(EXIT_FAILURE);
	}
	for(p1 = res1; p1 != NULL; p1 = p1->ai_next){
		sockfd1 = socket(p1->ai_family,p1->ai_socktype,p1->ai_protocol);
		if(sockfd1 == -1) continue;
		if(connect(sockfd1,p1->ai_addr,p1->ai_addrlen) == 0){
			break;
		}
		close(sockfd1);
	}
	freeaddrinfo(res1);
	if(p1 == NULL){
		fprintf(stderr, "Could not connect\n");
		exit(EXIT_FAILURE);
	}

	// connection established with time Server


	if(listen(sockfd,BACKLOG) == -1){
		perror("Server, listen");
		exit(EXIT_FAILURE);
	}


	printf("Server : Listening...\n");
	peer_addr_size = sizeof(struct sockaddr_storage);

	while(1){
		newfd = accept(sockfd,(struct sockaddr *)&peer_addr,&peer_addr_size);
		if((pid = fork()) == 0){
			close(sockfd);
			strcpy(buffer,"Connection Established");
			send(newfd,buffer,(size_t)sizeof(buffer),0);	
			
			strcpy(buffer,"timeQuery");
			send(sockfd1,buffer,(size_t)sizeof(buffer),0);	
			recv(sockfd1,buffer,sizeof(buffer),0);
			send(newfd,buffer,(size_t)sizeof(buffer),0);	

			printf("timeQuery : Received from timeServer & Sent\n");
			while(1){}
			// recv(newfd,buffer,sizeof(buffer),0);
			close(newfd);
			exit(0);
		}
		close(newfd);
	}

	
	

	

	return 0;
}
