#include<stdio.h>
#include<sys/types.h>
#include <sys/socket.h>
#include<netdb.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<math.h>
#include<signal.h>
#include<time.h>

#define BUFFER_SIZE 1024
#define BACKLOG 5

char buffer[BUFFER_SIZE];

void sig_handler(int signo){
	if(signo == SIGINT){
		printf("\nTimeServer : Exiting"), exit(0);
	}
}

char* getTime(){
	time_t TIME = time(NULL);
	return ctime(&TIME);
}

int main(int argc,char *argv[]){

	if(argc != 2){
		printf("Usage: ./timeServer <port_number>\n");
		exit(1);
	}

	signal(SIGINT,sig_handler);

	pid_t pid;
	int sockfd,status,newfd;
	struct addrinfo hints, *res,*p;
	struct sockaddr_storage peer_addr;
	socklen_t peer_addr_size;
	memset(&hints,0,sizeof hints);
	hints.ai_flags = AI_PASSIVE;
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;

	status = getaddrinfo(NULL,argv[1],&hints,&res);
	if(status != 0){
		fprintf(stderr, "timeServer, getaddrinfo: %s\n",gai_strerror(status));
		exit(EXIT_FAILURE);
	}
	for(p = res; p != NULL; p = p->ai_next){
		sockfd = socket(p->ai_family,p->ai_socktype,p->ai_protocol);
		if(sockfd == -1) continue;
		if(bind(sockfd,p->ai_addr,p->ai_addrlen) == 0) break;
		close(sockfd);
	}
	freeaddrinfo(res);
	if(p == NULL){
		fprintf(stderr, "timeServer, Could not bind\n");
		exit(EXIT_FAILURE);
	}
	if(listen(sockfd,BACKLOG) == -1){
		perror("timeServer, listen");
		exit(EXIT_FAILURE);
	}
	printf("timeServer : Listening...\n");
	peer_addr_size = sizeof(struct sockaddr_storage);
	newfd = accept(sockfd,(struct sockaddr *)&peer_addr,&peer_addr_size);
	while(1){
		recv(newfd,buffer,sizeof(buffer),0);
		strcpy(buffer,getTime());
		send(newfd,buffer,(size_t)sizeof(buffer),0);	
		printf("timeQuery : Sent to client-side server\n");
	}
	return 0;
}
